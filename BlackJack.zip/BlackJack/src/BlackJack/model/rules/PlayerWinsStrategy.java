package BlackJack.model.rules;

import BlackJack.model.Player;

public class PlayerWinsStrategy implements IWinnerRuleStrategy {

	@Override
	public boolean IsDealerWinner(Player a_playerScore, Player a_dealerScore, int g_maxScore) {
		if(a_dealerScore.CalcScore() > g_maxScore) {
			return false;
		}else if(a_playerScore.CalcScore() > g_maxScore) {
			return true;
		}
		return a_dealerScore.CalcScore() > a_playerScore.CalcScore();

	}
}
