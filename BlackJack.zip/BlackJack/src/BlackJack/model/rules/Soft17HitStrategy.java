package BlackJack.model.rules;

import BlackJack.model.Card;
import BlackJack.model.Player;

public class Soft17HitStrategy implements IHitStrategy {

	private final int g_hitlimit =17;

	@Override
	public boolean DoHit(Player a_dealer) {
		
		int dealerCurrentScore = a_dealer.CalcScore();
         System.out.println(dealerCurrentScore);
		if(dealerCurrentScore < g_hitlimit) 
			return true;

		int aceCount = 0;
		for(Card c : a_dealer.GetHand())
		{
			if (c.GetValue() == Card.Value.Ace ){

				aceCount = aceCount+1;
				for (int i = 1; i <= aceCount; i++) {
					if (dealerCurrentScore - (i * 10) < g_hitlimit) {   
						return true;
					}
				}

			}


		}


		return false;
	}

}
