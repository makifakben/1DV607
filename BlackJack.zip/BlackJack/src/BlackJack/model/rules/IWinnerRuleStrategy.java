package BlackJack.model.rules;

import BlackJack.model.Player;

public interface IWinnerRuleStrategy {

	boolean IsDealerWinner(Player a_playerScore, Player a_dealerScore, int g_maxScore);

}
